from . import UIControl

mClasses = [
    UIControl.Button_clearData,
    UIControl.Button_serverStart,
    UIControl.Button_serverStop,
    UIControl.UIpanel_TCP,
    UIControl.UIpanel_data,
]

